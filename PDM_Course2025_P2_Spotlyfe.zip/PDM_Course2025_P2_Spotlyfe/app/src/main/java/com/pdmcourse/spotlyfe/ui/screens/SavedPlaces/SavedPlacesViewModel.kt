package com.pdmcourse.spotlyfe.ui.screens.SavedPlaces

import androidx.lifecycle.ViewModel

class SavedPlacesViewModel: ViewModel() {

}