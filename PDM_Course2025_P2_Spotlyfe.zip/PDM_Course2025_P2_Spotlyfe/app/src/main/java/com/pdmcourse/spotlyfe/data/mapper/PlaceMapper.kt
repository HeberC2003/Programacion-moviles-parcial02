package com.pdmcourse.spotlyfe.data.mapper

import com.pdmcourse.spotlyfe.data.database.entities.PlaceEntity
import com.pdmcourse.spotlyfe.data.model.Place

fun PlaceEntity.toPlace(): Place =
    Place(name = name, remark = remark, latitude = latitude, longitude = longitude)

fun Place.toEntity(): PlaceEntity =
    PlaceEntity(name = name, remark = remark, latitude = latitude, longitude = longitude)
