package com.pdmcourse.spotlyfe.data.model

import android.content.Context
import com.pdmcourse.spotlyfe.data.database.AppDatabase
import com.pdmcourse.spotlyfe.data.repository.PlaceRepository
import com.pdmcourse.spotlyfe.ui.viewmodel.PlaceViewModel

object AppProvider {

    fun providePlaceViewModel(context: Context): PlaceViewModel {
        val db = AppDatabase.getDatabase(context)
        val dao = db.placeDao()
        val repository = PlaceRepository(dao)
        return PlaceViewModel(repository)
    }
}
