package com.pdmcourse.spotlyfe.data.repository

import com.pdmcourse.spotlyfe.data.database.dao.PlaceDao
import com.pdmcourse.spotlyfe.data.mapper.toEntity
import com.pdmcourse.spotlyfe.data.mapper.toPlace
import com.pdmcourse.spotlyfe.data.model.Place
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class PlaceRepository(private val dao: PlaceDao) {

    val places: Flow<List<Place>> = dao.getAllPlaces().map { list ->
        list.map { it.toPlace() }
    }

    suspend fun insert(place: Place) {
        dao.insertPlace(place.toEntity())
    }
}
