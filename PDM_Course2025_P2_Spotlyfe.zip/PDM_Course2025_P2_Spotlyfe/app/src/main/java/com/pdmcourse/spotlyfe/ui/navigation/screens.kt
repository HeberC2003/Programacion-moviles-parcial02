package com.pdmcourse.spotlyfe.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object SavedPlacesScreenNavigation

@Serializable
object CreateSpotScreenNavigation
