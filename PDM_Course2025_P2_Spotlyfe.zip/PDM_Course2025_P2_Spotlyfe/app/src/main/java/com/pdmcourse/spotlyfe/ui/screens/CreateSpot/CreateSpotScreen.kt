package com.pdmcourse.spotlyfe.ui.screens.CreateSpot

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.google.android.gms.maps.model.LatLng
import com.pdmcourse.spotlyfe.data.model.AppProvider
import com.pdmcourse.spotlyfe.data.model.Place
import com.pdmcourse.spotlyfe.ui.components.SelectLocationMap
import com.pdmcourse.spotlyfe.ui.navigation.SavedPlacesScreenNavigation

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateSpotScreen(navController: NavHostController) {
    val context = LocalContext.current
    val viewModel = remember { AppProvider.providePlaceViewModel(context) }

    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    // 👇 Estado para la ubicación seleccionada en el mapa
    var selectedLatLng by remember {
        mutableStateOf(LatLng(13.679024407659101, -89.23578718993471))
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Nuevo Lugar") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre del lugar") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Descripción") },
                modifier = Modifier.fillMaxWidth()
            )

            // 👇 Mapa para seleccionar ubicación
            SelectLocationMap(
                initialPosition = selectedLatLng,
                onLocationChanged = { newLatLng ->
                    selectedLatLng = newLatLng
                }
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    val newPlace = Place(
                        name = name,
                        remark = description,
                        latitude = selectedLatLng.latitude,
                        longitude = selectedLatLng.longitude
                    )
                    viewModel.insert(newPlace)
                    navController.navigate(SavedPlacesScreenNavigation)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar lugar")
            }
        }
    }
}
